#!/bin/bash
fonksiyon fonksiyonAdi {
sudo mv PULSE /home/pi/Desktop/
echo "Kurulum Tamamlandı."
}