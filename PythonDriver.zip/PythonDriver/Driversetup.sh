#!/bin/bash
fonksiyon fonksiyonAdi {
mv python3.7/ /home/pi/.local/lib
mv python2.7/ /home/pi/.local/lib
echo "Kurulum Tamamlandı."
}