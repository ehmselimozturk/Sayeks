#!/bin/bash
fonksiyon fonksiyonAdi {
mv PULSE /home/pi/Desktop/
echo "Kurulum Tamamlandı."
}