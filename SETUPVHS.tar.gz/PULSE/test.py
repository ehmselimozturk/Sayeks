from gpiozero import Button
from signal import pause
from datetime import datetime
from time import sleep
import tkinter as tk
from tkinter import ttk
import cups
from fpdf import FPDF
import shutil
from PIL import Image, ImageTk
from tkcalendar import *
button=Button(12)
threshold=.4;
pressedTime=0;
releasedTime=0;
diffTime = 0;
i = 0;
liste1 = []
liste2 = []
liste3 = []
liste4 = []
serinoliste = []
fark1b = 0
fark2b = 0
fark3b = 0
fark4b = 0
fark5b = 0
fark6b = 0
fark7b = 0
fark8b = 0
fark9b = 0
fark10b = 0
tarihliste=[]
def main():
    global serinoliste
    print("Uygulama işleme başladı")
    bas=tk.Tk()
    bas.title("Sayaç Ekspert")
    bas.geometry('500x500')
    bas.config(bg='#dadadb')
    bas.minsize(800,480)
    bas.maxsize(800,480)
    logo = ImageTk.PhotoImage(Image.open('/home/pi/Desktop/PULSE/vhs.png'))
    logo1=tk.Label(bas, text='Logo', image=logo)
    logo1.place(x=1,y=1)
    label2=tk.Label(bas, text='VHS ELEKTRONİK',fg='black', bg='#dadadb', font='bold')
    label2.pack()
    
    #serinogir.config(width=200)
    serinogir=tk.Label(bas, text='Sayaç Seri No Giriniz',fg='black', bg='#dadadb')
    serinogir.config(font=("Courier", 10))
    serinogir.pack()
   
    serino=tk.Entry(width=20)
    serino.pack()
    #serino.insert(0,"Seri Numarası Giriniz")

    ###########TARİH SAAT GİRİNİZ####
    tarih=tk.Label(bas, text='Tarih Bilgisini Giriniz',fg='black', bg='#dadadb')
    tarih.config(font=("Courier", 10))
    tarih.pack()
   
   # tarihgir=tk.Entry(width=20)
   # tarihgir.pack()
    cal = Calendar(bas, selectmode="day", year=2021, month=1, day=13)
    cal.pack(pady=5)


    def baslangic():
        global serinoliste
        global tarihliste
        def arayuz1():
            
            form=tk.Tk()
            form.title("SAYAC EKSPERT")
            form.geometry('500x500')
            form.config(bg='#dadadb')
            form.minsize(800,480)
            form.maxsize(800,480)
            #logovhs = ImageTk.PhotoImage(Image.open('vhs.png'))
            bilgi=tk.Label(form, text='',fg='black', bg='#dadadb')
            bilgi.config(font=("Courier", 10))
            bilgi.place(x=200,y=400)
            global fark1b
            global fark2b
            global fark3b
            global fark4b
            global fark5b
            global fark6b
            global fark7b
            global fark8b
            global fark9b
            global fark10b
            global tarihliste
            
          
            def hesapla():
                global fark1b
                global fark2b
                global fark3b
                global fark4b
                global fark5b
                global fark6b
                global fark7b
                global fark8b
                global fark9b
                global fark10b
                global tarihliste 

                label1=tk.Label(form, text='Sayaç Seri No:'+serinumarasi,fg='green', bg='#dadadb')
                label1.place(x=65,y=350)
                label1=tk.Label(form, text='Uygulama Tarihi:'+str(tarihliste[0]),fg='green', bg='#dadadb')
                label1.place(x=65,y=370)
                #1. PULSE
               
                label1=tk.Label(form, text='1.fark(sn):',fg='black')
                label1.place(x=65,y=50)
                label1=tk.Label(form, text=str(fark1b),fg='black',bg='#dadadb')
                label1.place(x=140,y=50)
        
        
                #2. PULSE
                
                label1=tk.Label(form, text='2.fark(sn):',fg='black')
                label1.place(x=65,y=80)
                label1=tk.Label(form, text=str(fark2b),fg='black')
                label1.place(x=140,y=80)
                #3. PULSE
               
                label1=tk.Label(form, text='3.fark(sn):',fg='black')
                label1.place(x=65,y=110)
                label1=tk.Label(form, text=str(fark3b),fg='black',bg='#dadadb')
                label1.place(x=140,y=110)
                #4. PULSE
               
                label1=tk.Label(form, text='4.fark(sn):',fg='black')
                label1.place(x=65,y=140)
                label1=tk.Label(form, text=str(fark4b),fg='black',bg='#dadadb')
                label1.place(x=140,y=140)
                #5. PULSE
               
                label1=tk.Label(form, text='5.fark(sn):',fg='black')
                label1.place(x=65,y=170)
                label1=tk.Label(form, text=str(fark5b),fg='black',bg='#dadadb')
                label1.place(x=140,y=170)
                #6. PULSE
                
                label1=tk.Label(form, text='6.fark(sn):',fg='black')
                label1.place(x=65,y=200)
                label1=tk.Label(form, text=str(fark6b),fg='black',bg='#dadadb')
                label1.place(x=140,y=200)
                #7. PULSE
              
                label1=tk.Label(form, text='7.fark(sn):',fg='black')
                label1.place(x=65,y=230)
                label1=tk.Label(form, text=str(fark7b),fg='black',bg='#dadadb')
                label1.place(x=140,y=230)
                #8. PULSE
              
                label1=tk.Label(form, text='8.fark(sn):',fg='black')
                label1.place(x=65,y=260)
                label1=tk.Label(form, text=str(fark8b),fg='black')
                label1.place(x=140,y=260)
                #9. PULSE
                
                label1=tk.Label(form, text='9.fark(sn):',fg='black')
                label1.place(x=65,y=290)
                label1=tk.Label(form, text=str(fark9b),fg='black',bg='#dadadb')
                label1.place(x=140,y=290)
                #10. PULSE
                
                label1=tk.Label(form, text='10.fark(sn):',fg='black')
                label1.place(x=65,y=320)
                label1=tk.Label(form, text=str(fark10b),fg='black',bg='#dadadb')
                label1.place(x=140,y=320)
            #ARAYUZ SONUC BUTTON
            buton=tk.Button(form, text='Sonuc Al', fg='black', bg='#299584', command=hesapla)
            buton.place(x=180,y=1)
            def logcopy():
                shutil.copy("/home/pi/log.txt", "/home/pi/Desktop/PULSE/")
                bilgi.config(text='LOG Kopyalandı',fg='black')    
            #ARAYUZ LOG BUTTON
            export=tk.Button(form, text='LOG Kopyala', fg='black', bg='#299584', command=logcopy)
            export.place(x=280,y=1)
            def resettxt():
                #label1=tk.Label(form, text='LOG temizlenmiştir.',fg='black', bg='red')
                # label1.place(x=200,y=390)
                bilgi.config(text='Log Temizlenmiştir!!', fg='red',bg='#dadadb')
                f = open('log.txt','w')
                f.write(str(liste4[0])+"  tarihinde veriler temizlenmiştir.\n\n\n\n")
                f.close()
                shutil.copy("/home/pi/log.txt", "/home/pi/Desktop/PULSE/")
            #ARAYUZ RES BUTTON   
            export=tk.Button(form, text='LOG Temizle', fg='red', bg='#299584', command=resettxt)
            export.place(x=400,y=1)
            #ARAYUZ PRİNT BUTTON
            def printer():
                #label1=tk.Label(form, text='Yazıcıya Gonderildi',fg='black', bg='yellow')
                #label1.place(x=200,y=410)
                bilgi.config(text='Yazıcıya Gönderildi',fg='black')
                conn = cups.Connection()
                printers = conn.getPrinters ()
                prin = conn.getDefault()
                myfile = "/home/pi/Desktop/PULSE/PULSE.pdf"
                conn.printFile (prin, myfile, "Project Report", {"Page Left":"0","cpi":"15"})


            ##PRİNTER BUTON
            export=tk.Button(form, text='YAZDIR', fg='black', bg='#299584', command=printer)
            export.place(x=520,y=1)
    
            form.mainloop()
            pause()
   
        def bitis():
            global liste2
            global liste1
            global liste4
            ######LOG KAYDI ALMA İŞLEMİ#######
            global liste2
            global liste1
            global liste4
            global serinoliste
            global fark1b
            global fark2b
            global fark3b
            global fark4b
            global fark5b
            global fark6b
            global fark7b
            global fark8b
            global fark9b
            global fark10b
            global tarihliste
            ######Fark Hesaplamaları 4 basamak####
            fark1=liste1[1]-liste1[0]
            fark1b=round(fark1,4)
            fark2=liste1[2]-liste1[1]
            fark2b=round(fark2,4)
            fark3=liste1[3]-liste1[2]
            fark3b=round(fark3,4)
            fark4=liste1[4]-liste1[3]
            fark4b=round(fark4,4)
            fark5=liste1[5]-liste1[4]
            fark5b=round(fark5,4)
            fark6=liste1[6]-liste1[5]
            fark6b=round(fark6,4)
            fark7=liste1[7]-liste1[6]
            fark7b=round(fark7,4)
            fark8=liste1[8]-liste1[7]
            fark8b=round(fark8,4)
            fark9=liste1[9]-liste1[8]
            fark9b=round(fark9,4)
            fark10=liste1[10]-liste1[9]
            fark10b=round(fark10,4)
            fark11=liste1[11]-liste1[10]
            fark11b=round(fark11,4)
            #label1=tk.Label(form, text='Text Dosyası Kaydedilmiştir',fg='green', bg='yellow')
            #label1.place(x=200,y=370)
            
            f = open('log.txt','a')
            f.write("VHS ELEKTRONİK PULSE OKUMA\n\n")
            f = open('log.txt','a')
            f.write("Sayaç Seri Numarası:"+str(serinoliste[0])+"\n\n\n")
            f = open('log.txt','a')
            f.write("Sistem Tarih Bilgisi:"+str(liste4[0])+"\n\n")
           
        
            #f = open('log.txt','a')
            #f.write("Uygulama Tarigi\n")
            #f = open('log.txt','a')
            #f.write("Uygulama Tarihi:  ")
            f = open('log.txt','a')
            f.write("Uygulama Tarihi:"+str(tarihliste[0])+"\n\n")
        
            #f.write("2. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f = open('log.txt','a')
            #f.write(str(liste4[1])+"\n")
        
            #f.write("3. Pulse Tarihi (sn):  ")
            #f.write(str(liste4[2])+"\n")
        
            #f.write("4. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[3])+"\n")
        
            #f.write("5. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[4])+"\n")
        
            #f.write("6. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[5])+"\n")
        
            #f.write("7. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[6])+"\n")
        
            #f.write("8. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[7])+"\n")
        
            #f.write("9. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[8])+"\n")
        
            #f.write("10. Pulse Tarihi (sn):  ")
            #f = open('log.txt','a')
            #f.write(str(liste4[9])+"\n")
        
        
            #PULSE FARKLARI TXT
            f.write("Pulse Süreleri\n\n")
            f = open('log.txt','a')
            f.write("1-2 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark1b)+"\n")
        
            f.write("2-3 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark2b)+"\n")
        
            f.write("3-4 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark3b)+"\n")
        
            f.write("4-5 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark4b)+"\n")
        
            f.write("5-6 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark5b)+"\n")
        
            f.write("6-7 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark6b)+"\n")
        
            f.write("7-8 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark7b)+"\n")
        
            f.write("8-9 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark8b)+"\n")
        
            f.write("9-10 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark9b)+"\n")
        
            f.write("10-11 Pulse Arası Süre (sn):  ")
            f = open('log.txt','a')
            f.write(str(fark10b)+"\n\n\n")
        
            f.close()
            shutil.copy("/home/pi/log.txt", "/home/pi/Desktop/PULSE/")
            #TEST

            pulsef1 =  liste1[1]-liste1[0]
            print(pulsef1)
            print("pulsef geldi")
            #test bitis

            #PDF OLUSTURMA
            pdf = FPDF()
            pdf.add_page()
            pdf.image('/home/pi/Desktop/PULSE/vhs.png',0,8,30)
            pdf.set_xy(30,0)
            pdf.set_font('Arial', 'B', 15)
            pdf.cell(10, 40, 'Pulse Okuma')
            
            #PULSE TARİHLERİ
            pdf.set_xy(0,10)
            pdf.set_font('Times', 'B', 11)
            pdf.cell(10, 50, 'UYGULAMA TARIHLERI')
            ###SERİ NO###
            pdf.set_xy(0,15)
            pdf.set_font('Times', 'B', 10)
            pdf.cell(10, 50, 'Sayac Seri No:')
            pdf.set_xy(25,15)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(serinoliste[0]))
            
            pdf.set_xy(0,20)
            pdf.set_font('Times', 'B', 10)
            pdf.cell(10, 50, 'Uygulama Tarihi:')

            pdf.set_xy(30,20)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(tarihliste[0]))
            

            #PULSE FARKLARI
            pdf.set_xy(0,30)
            pdf.set_font('Times', 'B', 11)
            pdf.cell(10, 50, 'PULSE FARKLARI')
            

            #1-2 fark
            pdf.set_xy(0,35)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '1-2 Pulse Suresi(sn):')

            pdf.set_xy(35,35)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark1b))
            #2-3 fark
            pdf.set_xy(0,40)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '2-3 Pulse Suresi (sn):')

            pdf.set_xy(35,40)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark2b))
            #3-4 fark
            pdf.set_xy(0,45)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '3-4 Pulse Suresi (sn):')

            pdf.set_xy(35,45)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark3b))
            #4-5 Fark
            pdf.set_xy(0,50)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '4-5 Pulse Suresi (sn):')

            pdf.set_xy(35,50)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark4b))
            #5-6 fark
            pdf.set_xy(0,55)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '5-6 Pulse Suresi (sn):')

            pdf.set_xy(35,55)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark5b))
            #6-7 Fark
            pdf.set_xy(0,60)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '6-7 Pulse Suresi (sn):')

            pdf.set_xy(35,60)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark6b))
            #7-8 Fark
            pdf.set_xy(0,65)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '7-8 Pulse Suresi (sn):')

            pdf.set_xy(35,65)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark7b))
            #8-9 fark
            pdf.set_xy(0,70)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '8-9 Pulse Suresi (sn):')

            pdf.set_xy(35,70)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark8b))
            #9-10
            pdf.set_xy(0,75)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '9-10 Pulse Suresi (sn):')

            pdf.set_xy(35,75)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark9b))
            #10-11 Fark
            pdf.set_xy(0,80)
            pdf.set_font('Times', 'I', 10)
            pdf.cell(10, 50, '10-11 Pulse Suresi (sn):')

            pdf.set_xy(38,80)
            pdf.set_font('Arial', '', 9)
            pdf.cell(10, 50, str(fark10b))

            pdf.output('PULSE.pdf', 'F')
            print("Pulse Okuma Tamamlanmıştır")
            shutil.copy("/home/pi/PULSE.pdf", "/home/pi/Desktop/PULSE/")
            page=tk.Button(bas, text='Sonuc', fg='black', bg='#299584', command=arayuz1)
            page.place(x=360,y=430)
            arayuz1()
            

            
        def checkPressed():
            global pressedTime
            pressedTime = datetime.now()        
            print(pressedTime, " pressed")
            
        def checkReleased():
            global pressedTime
            global releasedTime
            releasedTime = datetime.now()
            print(releasedTime, " released")
    
            if pressedTime :
                diffTime = releasedTime - pressedTime
        
                print("diffTime => ", diffTime.total_seconds())
        
                if diffTime.total_seconds() > threshold:
                    print(pressedTime," Pulse occured")
                    a = datetime.timestamp(pressedTime)
            
                    global liste1
                    global liste2
                    global liste3
                    global liste4
                    global i
            
                    liste1+=[a]
                    liste2+=[diffTime]
                    liste3+=[i]        
                    liste4+=[pressedTime]
                    i=i+1
                    
                    anlikveri.config(text="Durum:"+str(i)+". Pulse Okundu")
                    anlikveri.place(x=320, y=410)
                    if i==12:
                        print(liste1[11])
                        bitis()
                            
                
                else:
            
                    print("noise")
                    
                    anlikveri.config(text='Durum: noise               ')
                    anlikveri.place(x=320, y=410)
        
        
            ####Seri no import####

        serinumarasi=serino.get()
        #tarihbilgisi=cal.get_date()
        tarihliste+=[cal.get_date()]
        serinoliste+=[serinumarasi]
        print(tarihliste[0])
        if len(serino.get()) == 0:
            
            anlikveri=tk.Label(bas, text='Sayaç Seri No Giriniz                              ',fg='red', bg='#dadadb')
            anlikveri.config(font=("Courier", 10))
            anlikveri.place(x=320,y=410)
        else:
            
            anlikveri=tk.Label(bas, text='Sayaç Seri No:'+serinumarasi+'   Tarih:'+str(tarihliste[0]),fg='black', bg='#dadadb')
            anlikveri.config(font=("Courier", 10))
            anlikveri.place(x=170,y=410)
            label2=tk.Label(bas, text='Islem Başlamıştır Lütfen Bitene Kadar Bekleyiniz',fg='black', bg='#299584')
            label2.place(x=250,y=380)
            button.when_pressed = checkPressed
            button.when_released = checkReleased
            print(serinoliste[0])
    ac=tk.Button(bas, text='Islemı Baslat', fg='black', bg='#299584', command=baslangic)
    ac.place(x=345,y=350)
    bas.mainloop()
    
if __name__ == "__main__":
    main()



