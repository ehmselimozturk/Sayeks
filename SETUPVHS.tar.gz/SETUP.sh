#!/bin/bash
fonksiyon fonksiyonAdi {
cp -r PULSE /home/pi/Desktop/
echo "Kurulum Tamamlandı."
}